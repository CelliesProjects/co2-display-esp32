#include <Regexp.h>
#include <Arduino.h>

#define LRC_TIMESTAMP_LENGTH 10

unsigned long timestampToMillis(const char *timestamp);