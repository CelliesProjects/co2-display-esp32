//============================================================================
// 3-wire SPI initialization for CFAF480480A0-040T
// This display uses the ST7701 controller from Sitronix
//============================================================================
void LCD_Write_Command(uint8_t command)
  {
  //Select the LCD
  CLR_DISP_CS;
  uint16_t
    address_and_command;
  //Select the Command register:
  address_and_command=0x0000;
  //Set the low 8 bits from the caller
  address_and_command|=command;
  // Send the data
  uint16_t
    mask;
  for(mask=0x0100;0!=mask;mask>>=1)
     {
     //Set or clear the data bit = MOSI
     if(0!=(mask&address_and_command))
       {
       SET_MOSI;
       }
     else
       {
       CLR_MOSI;
       }
     //Toggle the clock
     SET_SCK;
     CLR_SCK;
     }
  //De-select the LCD
  SET_DISP_CS;
  }
//============================================================================
void LCD_Write_Data(uint8_t data)
  {
  //Select the LCD
  CLR_DISP_CS;
  uint16_t
    address_and_data;
  //Select the Data register;
  address_and_data=0x0100;
  //Set the low 8 bits from the caller
  address_and_data|=data;
  // Send the data
  uint16_t
    mask;
  for(mask=0x0100;0!=mask;mask>>=1)
     {
     //Set or clear the data bit = MOSI
     if(0!=(mask&address_and_data))
       {
       SET_MOSI;
       }
     else
       {
       CLR_MOSI;
       }
     //Toggle the clock
     SET_SCK;
     CLR_SCK;
     }
  //De-select the LCD
  SET_DISP_CS;
  }
//============================================================================
void ST7701_LCD_Init(void)
  {
  //Hardware reset the LCD controller
  CLR_DISP_RST;
  delay(20);
  SET_DISP_RST;
  delay(120);


  LCD_Write_Command(0x11); //Sleep Out
  delay(120);
  LCD_Write_Command(0xFF); //Command2 BKx Selection: Select BK0 Functions
  LCD_Write_Data(0x77);
  LCD_Write_Data(0x01);
  LCD_Write_Data(0x00);
  LCD_Write_Data(0x00);
  LCD_Write_Data(0x10);

  LCD_Write_Command(0xC0); //Display Line Setting
  LCD_Write_Data(0x3B);
  LCD_Write_Data(0x00);

  LCD_Write_Command(0xC1); //Porch Control
  LCD_Write_Data(0x0D);
  LCD_Write_Data(0x02);

  LCD_Write_Command(0xC2); //Inversion selection & Frame Rate Control
  LCD_Write_Data(0x21);
  LCD_Write_Data(0x08);

  LCD_Write_Command(0xB0); //Positive Voltage Gamma Control
  LCD_Write_Data(0x00);
  LCD_Write_Data(0x11);
  LCD_Write_Data(0x18);
  LCD_Write_Data(0x0E);
  LCD_Write_Data(0x11);
  LCD_Write_Data(0x06);
  LCD_Write_Data(0x07);
  LCD_Write_Data(0x08);
  LCD_Write_Data(0x07);
  LCD_Write_Data(0x22);
  LCD_Write_Data(0x04);
  LCD_Write_Data(0x12);
  LCD_Write_Data(0x0F);
  LCD_Write_Data(0xAA);
  LCD_Write_Data(0x31);
  LCD_Write_Data(0x18);

  LCD_Write_Command(0xB1); //Negative Voltage Gamma Control
  LCD_Write_Data(0x00);
  LCD_Write_Data(0x11);
  LCD_Write_Data(0x19);
  LCD_Write_Data(0x0E);
  LCD_Write_Data(0x12);
  LCD_Write_Data(0x07);
  LCD_Write_Data(0x08);
  LCD_Write_Data(0x08);
  LCD_Write_Data(0x08);
  LCD_Write_Data(0x22);
  LCD_Write_Data(0x04);
  LCD_Write_Data(0x11);
  LCD_Write_Data(0x11);
  LCD_Write_Data(0xA9);
  LCD_Write_Data(0x32);
  LCD_Write_Data(0x18);

  LCD_Write_Command(0xFF); //Command2 BKx Selection: Select BK1 Functions
  LCD_Write_Data(0x77);
  LCD_Write_Data(0x01);
  LCD_Write_Data(0x00);
  LCD_Write_Data(0x00);
  LCD_Write_Data(0x11);

  LCD_Write_Command(0xB0); //Vop Amplitude setting
  LCD_Write_Data(0x60);

  LCD_Write_Command(0xB1); //VCOM amplitude setting
  LCD_Write_Data(0x30);

  LCD_Write_Command(0xB2); //VGH Voltage setting
  LCD_Write_Data(0x87);

  LCD_Write_Command(0xB3); //TEST Command Setting
  LCD_Write_Data(0x80);

  LCD_Write_Command(0xB5); //VGL Voltage setting
  LCD_Write_Data(0x49);

  LCD_Write_Command(0xB7); //Power Control 1
  LCD_Write_Data(0x85);

  LCD_Write_Command(0xB8); //Power Control 2
  LCD_Write_Data(0x21);

  LCD_Write_Command(0xC1); //Source pre_drive timing set1
  LCD_Write_Data(0x78);

  LCD_Write_Command(0xC2); //Source EQ2 Setting
  LCD_Write_Data(0x78);
  delay(20);


  LCD_Write_Command(0xE0);
  LCD_Write_Data(0x00);
  LCD_Write_Data(0x1B);
  LCD_Write_Data(0x02);

  LCD_Write_Command(0xE1);
  LCD_Write_Data(0x08);
  LCD_Write_Data(0xA0);
  LCD_Write_Data(0x00);
  LCD_Write_Data(0x00);
  LCD_Write_Data(0x07);
  LCD_Write_Data(0xA0);
  LCD_Write_Data(0x00);
  LCD_Write_Data(0x00);
  LCD_Write_Data(0x00);
  LCD_Write_Data(0x44);
  LCD_Write_Data(0x44);

  LCD_Write_Command(0xE2);
  LCD_Write_Data(0x11);
  LCD_Write_Data(0x11);
  LCD_Write_Data(0x44);
  LCD_Write_Data(0x44);
  LCD_Write_Data(0xED);
  LCD_Write_Data(0xA0);
  LCD_Write_Data(0x00);
  LCD_Write_Data(0x00);
  LCD_Write_Data(0xEC);
  LCD_Write_Data(0xA0);
  LCD_Write_Data(0x00);
  LCD_Write_Data(0x00);

  LCD_Write_Command(0xE3);
  LCD_Write_Data(0x00);
  LCD_Write_Data(0x00);
  LCD_Write_Data(0x11);
  LCD_Write_Data(0x11);

  LCD_Write_Command(0xE4);
  LCD_Write_Data(0x44);
  LCD_Write_Data(0x44);

  LCD_Write_Command(0xE5);
  LCD_Write_Data(0x0A);
  LCD_Write_Data(0xE9);
  LCD_Write_Data(0xD8);
  LCD_Write_Data(0xA0);
  LCD_Write_Data(0x0C);
  LCD_Write_Data(0xEB);
  LCD_Write_Data(0xD8);
  LCD_Write_Data(0xA0);
  LCD_Write_Data(0x0E);
  LCD_Write_Data(0xED);
  LCD_Write_Data(0xD8);
  LCD_Write_Data(0xA0);
  LCD_Write_Data(0x10);
  LCD_Write_Data(0xEF);
  LCD_Write_Data(0xD8);
  LCD_Write_Data(0xA0);

  LCD_Write_Command(0xE6);
  LCD_Write_Data(0x00);
  LCD_Write_Data(0x00);
  LCD_Write_Data(0x11);
  LCD_Write_Data(0x11);

  LCD_Write_Command(0xE7);
  LCD_Write_Data(0x44);
  LCD_Write_Data(0x44);

  LCD_Write_Command(0xE8);
  LCD_Write_Data(0x09);
  LCD_Write_Data(0xE8);
  LCD_Write_Data(0xD8);
  LCD_Write_Data(0xA0);
  LCD_Write_Data(0x0B);
  LCD_Write_Data(0xEA);
  LCD_Write_Data(0xD8);
  LCD_Write_Data(0xA0);
  LCD_Write_Data(0x0D);
  LCD_Write_Data(0xEC);
  LCD_Write_Data(0xD8);
  LCD_Write_Data(0xA0);
  LCD_Write_Data(0x0F);
  LCD_Write_Data(0xEE);
  LCD_Write_Data(0xD8);
  LCD_Write_Data(0xA0);

  LCD_Write_Command(0xEB);
  LCD_Write_Data(0x02);
  LCD_Write_Data(0x00);
  LCD_Write_Data(0xE4);
  LCD_Write_Data(0xE4);
  LCD_Write_Data(0x88);
  LCD_Write_Data(0x00);
  LCD_Write_Data(0x40);

  LCD_Write_Command(0xEC);
  LCD_Write_Data(0x3C);
  LCD_Write_Data(0x00);

  LCD_Write_Command(0xED);
  LCD_Write_Data(0xAB);
  LCD_Write_Data(0x89);
  LCD_Write_Data(0x76);
  LCD_Write_Data(0x54);
  LCD_Write_Data(0x02);
  LCD_Write_Data(0xFF);
  LCD_Write_Data(0xFF);
  LCD_Write_Data(0xFF);
  LCD_Write_Data(0xFF);
  LCD_Write_Data(0xFF);
  LCD_Write_Data(0xFF);
  LCD_Write_Data(0x20);
  LCD_Write_Data(0x45);
  LCD_Write_Data(0x67);
  LCD_Write_Data(0x98);
  LCD_Write_Data(0xBA);

  LCD_Write_Command(0xFF); //Command2 BKx Selection: Select BK0 Functions and disable CN2
  LCD_Write_Data(0x77);
  LCD_Write_Data(0x01);
  LCD_Write_Data(0x00);
  LCD_Write_Data(0x00);
  LCD_Write_Data(0x00);

  LCD_Write_Command(0x29); //Display On

  
  }
//============================================================================